package com.twofromkt.ecomap.activities;

import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.support.design.widget.BottomSheetBehavior;
import android.support.v4.app.ActivityCompat;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.twofromkt.ecomap.db.Place;

import java.util.ArrayList;
import java.util.HashMap;

import static com.twofromkt.ecomap.util.LocationUtil.getLatLng;
import static com.twofromkt.ecomap.util.LocationUtil.getLocation;
import static com.twofromkt.ecomap.util.Util.activeMarkers;
import static com.twofromkt.ecomap.util.Util.includeAll;
import static com.twofromkt.ecomap.util.Util.markersToPlace;

public class MapActivityUtil {

    static void showBottomInfo(MapActivity act, boolean showSheet) {
        act.navigationButton.setVisibility(View.VISIBLE);
        act.locationButton.setVisibility(View.INVISIBLE);
        act.floatingMenu.setVisibility(View.INVISIBLE);
        if (showSheet) {
            act.bottomInfo.setState(BottomSheetBehavior.STATE_COLLAPSED);
        }
    }

    static void showBottomList(MapActivity act) {
        act.locationButton.setVisibility(View.INVISIBLE);
        act.bottomList.setState(BottomSheetBehavior.STATE_COLLAPSED);
    }

    static void hideBottomInfo(MapActivity act) {
        act.navigationButton.setVisibility(View.INVISIBLE);
        act.locationButton.setVisibility(View.VISIBLE);
        act.floatingMenu.setVisibility(View.VISIBLE);
        act.bottomInfo.setState(BottomSheetBehavior.STATE_HIDDEN);
    }

    static void hideBottomList(MapActivity act) {
        act.locationButton.setVisibility(View.VISIBLE);
        act.bottomList.setState(BottomSheetBehavior.STATE_HIDDEN);
    }

    static void closeKeyboard(MapActivity act) {
        View view = act.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) act.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    static void closeFloatingMenu(MapActivity act) {
        act.floatingMenu.close(true);
    }

    static boolean isBottomOpened(MapActivity act) {
        return act.bottomInfo.getState() != BottomSheetBehavior.STATE_HIDDEN;
    }

    static Marker addMarker(GoogleMap mMap, Place x) {
        Marker m = mMap.addMarker(new MarkerOptions().position(getLatLng(x.location)).title(x.name));
        activeMarkers.add(m);
        markersToPlace.put(m, x);
        return m;
    }

    static <T extends Place> void addMarkers(ArrayList<T> p, GoogleMap mMap) {
        ArrayList<LatLng> pos = new ArrayList<>();
        for (Place place : p) {
            addMarker(mMap, place);
            pos.add(getLatLng(place.location));
        }
        LatLngBounds bounds = includeAll(pos);
        CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, 10);
        mMap.animateCamera(cu);
    }

    static void clearMarkers() {
        for (Marker m : activeMarkers)
            m.remove();
        activeMarkers = new ArrayList<>();
        markersToPlace = new HashMap<>();
    }

    static void addLocationSearch(MapActivity act, GoogleMap map) {
        if (ActivityCompat.checkSelfPermission(act,
                android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        map.setMyLocationEnabled(true);
        map.getUiSettings().setMyLocationButtonEnabled(false);
    }
}
